# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['anespy', 'anespy.data', 'anespy.var_lists']

package_data = \
{'': ['*']}

install_requires = \
['importlib-resources>=5.10.1,<6.0.0',
 'numpy>=1.23.5,<2.0.0',
 'pandas>=1.5.2,<2.0.0',
 'requests>=2.28.1,<3.0.0']

setup_kwargs = {
    'name': 'anespy',
    'version': '0.1.4.4',
    'description': 'A package for using ANES data in Python',
    'long_description': "# anespy\n\nA package for using ANES data in Python\n\n## Installation\n\n```bash\n$ pip install anespy\n```\n\n## Usage\n\n#### Loading ANES Data\n\nOne of the primary challenges of working with ANES data is that it's all over the place, and there is no *true* API for repeatedly accessing the data. Getting data files requires clicking a button for the format you'd like, which means that there are no user-facing static links for getting data. However, there is a somewhat hidden internal API that the site makes requests to when you select the file you wish to download. This package leverages this request system to acquire the datasets. \n\nThe function ````load_ANES_data(year, add_names = False)```` takes two arguments:\n1. ```year```: year of the data you would like to access\n2. ```add_names```: if you want to swap the variable names for their more complete, context-inclusive names (defaults to ```False```)\n\n\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`anespy` was created by Jackson Rudoff. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`anespy` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n",
    'author': 'Jackson Rudoff',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
