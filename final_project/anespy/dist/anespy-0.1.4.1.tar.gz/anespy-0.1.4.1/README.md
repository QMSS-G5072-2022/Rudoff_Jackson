# anespy

A package for using ANES data in Python

## Installation

```bash
$ pip install anespy
```

## Usage

#### Loading ANES Data

One of the primary challenges of working with ANES data is that it's all over the place, and there is no *true* API for repeatedly accessing the data. Getting data files requires clicking a button for the format you'd like, which means that there are no user-facing static links for getting data. However, there is a somewhat hidden internal API that the site makes requests to when you select the file you wish to download. This package leverages this request system to acquire the datasets. 

The function ````load_ANES_data(year, add_names = False)```` takes two arguments:
1. ```year```: year of the data you would like to access
2. ```add_names```: if you want to swap the variable names for their more complete, context-inclusive names (defaults to ```False```)



## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`anespy` was created by Jackson Rudoff. It is licensed under the terms of the MIT license.

## Credits

`anespy` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
